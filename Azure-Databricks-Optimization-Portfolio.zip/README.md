# Azure Databricks Cost and Performance Optimization

An independent portfolio project that demonstrates cost attribution, compute right-sizing, anomaly detection, and Spark performance analysis on Azure Databricks.

## What the project implements

- Builds daily workspace-, job-, and cluster-level cost marts from `system.billing.usage` and `system.billing.list_prices`.
- Uses Databricks billing metadata and custom tags to attribute usage to teams and projects.
- Identifies recurring compute with low utilization or excessive idle time as right-sizing candidates.
- Detects unusual daily spending using rolling averages and standard-deviation thresholds.
- Parses Spark event logs from Azure Data Lake Storage or DBFS into Delta tables for stage, task, shuffle, and executor analysis.
- Deploys the workflow as a Databricks bundle with parameterized catalog, schema, and event-log paths.

## Architecture

```text
Databricks system tables ─┐
                          ├─> Cost marts ─> Right-sizing recommendations
Azure Cost/price metadata ┘             └─> Cost anomaly alerts

Spark event logs in ADLS/DBFS ─> Event parser ─> Delta performance metrics
```

## Project structure

```text
databricks.yml
resources/
  optimization_job.yml
src/
  build_cost_marts.py
  detect_cost_anomalies.py
  generate_right_sizing_recommendations.py
  parse_spark_event_logs.py
```

## Prerequisites

- Azure Databricks workspace with Unity Catalog.
- Access to billing and compute system tables.
- Databricks CLI configured for the target workspace.
- A Unity Catalog catalog and schema for the generated Delta tables.
- Spark event-log delivery configured to an accessible ADLS or DBFS path.

## Deploy

```powershell
databricks bundle validate -t dev
databricks bundle deploy -t dev
databricks bundle run cost_and_performance_optimization -t dev
```

## Outputs

| Table | Purpose |
|---|---|
| `daily_compute_cost` | Daily estimated Databricks cost by workspace, job, cluster, SKU, team, and project |
| `daily_cost_anomalies` | Daily costs compared with a seven-day rolling baseline |
| `compute_right_sizing_candidates` | Clusters and jobs that require configuration or utilization review |
| `spark_stage_metrics` | Stage duration, task counts, shuffle volume, and executor runtime extracted from event logs |

## Resume-safe description

> Built an independent Azure Databricks optimization prototype using Unity Catalog system tables, PySpark, Delta Lake, and Databricks bundles to attribute job-level cost, detect spending anomalies, identify compute right-sizing candidates, and analyze Spark event-log performance.

This project is a portfolio implementation. It does not claim production savings or deployment at an employer.

## References

- https://learn.microsoft.com/azure/databricks/admin/system-tables/billing
- https://learn.microsoft.com/azure/databricks/admin/usage/system-tables
- https://learn.microsoft.com/azure/databricks/dev-tools/bundles/
- https://learn.microsoft.com/azure/databricks/compute/cluster-metrics

