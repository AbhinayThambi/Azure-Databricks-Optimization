import argparse

from pyspark.sql import SparkSession
from pyspark.sql import functions as F


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--event-log-path", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    target_table = f"`{args.catalog}`.`{args.schema}`.spark_stage_metrics"

    events = spark.read.json(args.event_log_path)
    task_events = events.filter(F.col("Event") == "SparkListenerTaskEnd").select(
        F.col("Stage ID").alias("stage_id"),
        F.col("Stage Attempt ID").alias("stage_attempt_id"),
        (
            F.col("Task Info.Finish Time") - F.col("Task Info.Launch Time")
        ).alias("task_duration_ms"),
        F.col("Task Metrics.Executor Run Time").alias("executor_run_time_ms"),
        F.col("Task Metrics.Input Metrics.Bytes Read").alias("input_bytes"),
        F.col("Task Metrics.Output Metrics.Bytes Written").alias("output_bytes"),
        F.col("Task Metrics.Shuffle Read Metrics.Remote Bytes Read").alias(
            "shuffle_remote_bytes_read"
        ),
        F.col("Task Metrics.Shuffle Write Metrics.Shuffle Bytes Written").alias(
            "shuffle_bytes_written"
        ),
    )

    stage_names = (
        events.filter(F.col("Event") == "SparkListenerStageSubmitted")
        .select(
            F.col("Stage Info.Stage ID").alias("stage_id"),
            F.col("Stage Info.Stage Attempt ID").alias("stage_attempt_id"),
            F.col("Stage Info.Stage Name").alias("stage_name"),
        )
        .dropDuplicates(["stage_id", "stage_attempt_id"])
    )

    metrics = (
        task_events.groupBy("stage_id", "stage_attempt_id")
        .agg(
            F.count("*").alias("task_count"),
            F.max("task_duration_ms").alias("stage_wall_clock_ms"),
            F.sum("task_duration_ms").alias("total_task_duration_ms"),
            F.sum("executor_run_time_ms").alias("executor_run_time_ms"),
            F.sum("input_bytes").alias("input_bytes"),
            F.sum("output_bytes").alias("output_bytes"),
            F.sum("shuffle_remote_bytes_read").alias("shuffle_remote_bytes_read"),
            F.sum("shuffle_bytes_written").alias("shuffle_bytes_written"),
        )
        .join(stage_names, ["stage_id", "stage_attempt_id"], "left")
        .withColumn("processed_at", F.current_timestamp())
    )

    (
        metrics.write.format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(target_table)
    )


if __name__ == "__main__":
    main()
