import argparse

from pyspark.sql import SparkSession


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--schema", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    target = f"`{args.catalog}`.`{args.schema}`"

    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {target}")
    spark.sql(
        f"""
        CREATE OR REPLACE TABLE {target}.daily_compute_cost
        USING DELTA
        AS
        WITH priced_usage AS (
          SELECT
            usage.usage_date,
            usage.workspace_id,
            usage.sku_name,
            usage.usage_metadata.job_id AS job_id,
            usage.usage_metadata.cluster_id AS cluster_id,
            COALESCE(usage.custom_tags['team'], 'unassigned') AS team,
            COALESCE(usage.custom_tags['project'], 'unassigned') AS project,
            usage.usage_quantity,
            pricing.pricing.default AS price_per_unit
          FROM system.billing.usage AS usage
          INNER JOIN system.billing.list_prices AS pricing
            ON usage.cloud = pricing.cloud
            AND usage.sku_name = pricing.sku_name
            AND usage.usage_start_time >= pricing.price_start_time
            AND (
              pricing.price_end_time IS NULL
              OR usage.usage_start_time < pricing.price_end_time
            )
          WHERE usage.usage_unit = 'DBU'
            AND usage.usage_date >= CURRENT_DATE() - INTERVAL 90 DAYS
        )
        SELECT
          usage_date,
          workspace_id,
          job_id,
          cluster_id,
          sku_name,
          team,
          project,
          SUM(usage_quantity) AS dbus,
          SUM(usage_quantity * price_per_unit) AS estimated_cost
        FROM priced_usage
        GROUP BY
          usage_date,
          workspace_id,
          job_id,
          cluster_id,
          sku_name,
          team,
          project
        """
    )


if __name__ == "__main__":
    main()

