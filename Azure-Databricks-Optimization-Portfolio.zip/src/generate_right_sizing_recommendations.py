import argparse

from pyspark.sql import SparkSession


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--schema", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    target = f"`{args.catalog}`.`{args.schema}`"

    spark.sql(
        f"""
        CREATE OR REPLACE TABLE {target}.compute_right_sizing_candidates
        USING DELTA
        AS
        WITH cluster_cost AS (
          SELECT
            cluster_id,
            workspace_id,
            COUNT(DISTINCT usage_date) AS active_days,
            SUM(dbus) AS total_dbus,
            SUM(estimated_cost) AS total_estimated_cost,
            AVG(estimated_cost) AS average_daily_cost
          FROM {target}.daily_compute_cost
          WHERE cluster_id IS NOT NULL
          GROUP BY cluster_id, workspace_id
        )
        SELECT
          cost.*,
          clusters.cluster_name,
          clusters.driver_node_type,
          clusters.worker_node_type,
          clusters.worker_count,
          CASE
            WHEN active_days >= 14 AND average_daily_cost > 0
              THEN 'Review worker count, autoscaling range, runtime, and termination settings'
            ELSE 'Monitor'
          END AS recommendation
        FROM cluster_cost AS cost
        LEFT JOIN system.compute.clusters AS clusters
          ON cost.workspace_id = clusters.workspace_id
          AND cost.cluster_id = clusters.cluster_id
        QUALIFY ROW_NUMBER() OVER (
          PARTITION BY cost.workspace_id, cost.cluster_id
          ORDER BY clusters.change_time DESC
        ) = 1
        """
    )


if __name__ == "__main__":
    main()

