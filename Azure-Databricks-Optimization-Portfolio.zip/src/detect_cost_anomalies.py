import argparse

from pyspark.sql import SparkSession


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--schema", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    spark = SparkSession.builder.getOrCreate()
    target = f"`{args.catalog}`.`{args.schema}`"

    spark.sql(
        f"""
        CREATE OR REPLACE TABLE {target}.daily_cost_anomalies
        USING DELTA
        AS
        WITH daily_cost AS (
          SELECT
            usage_date,
            workspace_id,
            team,
            project,
            SUM(estimated_cost) AS estimated_cost
          FROM {target}.daily_compute_cost
          GROUP BY usage_date, workspace_id, team, project
        ),
        baseline AS (
          SELECT
            *,
            AVG(estimated_cost) OVER (
              PARTITION BY workspace_id, team, project
              ORDER BY usage_date
              ROWS BETWEEN 7 PRECEDING AND 1 PRECEDING
            ) AS rolling_average,
            STDDEV_SAMP(estimated_cost) OVER (
              PARTITION BY workspace_id, team, project
              ORDER BY usage_date
              ROWS BETWEEN 7 PRECEDING AND 1 PRECEDING
            ) AS rolling_stddev
          FROM daily_cost
        )
        SELECT
          *,
          CASE
            WHEN rolling_stddev IS NOT NULL
              AND estimated_cost > rolling_average + (2 * rolling_stddev)
            THEN true
            ELSE false
          END AS is_anomaly
        FROM baseline
        """
    )


if __name__ == "__main__":
    main()

